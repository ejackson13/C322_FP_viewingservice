package edu.iu.c322.finalproject.viewingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewingserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViewingserviceApplication.class, args);
	}

}
