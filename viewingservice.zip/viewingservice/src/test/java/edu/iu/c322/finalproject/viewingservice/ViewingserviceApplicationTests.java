package edu.iu.c322.finalproject.viewingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewingserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
